from .models import Task
from django.forms import Modelform


class TaskForm(Modelform):
    class Meta:
        model = Task
        fields = ["title", "task"]